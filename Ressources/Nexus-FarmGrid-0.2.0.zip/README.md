Allows for all plants planted with the cultivator to automatically be snapped and placed into a grid in which they will have enough space to grow.

Created by
Sarcen